package com.vorix.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import com.vorix.app.ui.animation.VorixSplashScreen
import java.util.concurrent.atomic.AtomicBoolean

class SplashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val firstFrameReady = AtomicBoolean(false)
        val systemSplash = installSplashScreen()
        systemSplash.setKeepOnScreenCondition { !firstFrameReady.get() }
        super.onCreate(savedInstanceState)

        window.statusBarColor = android.graphics.Color.rgb(7, 7, 13)
        window.navigationBarColor = android.graphics.Color.rgb(7, 7, 13)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        setContent {
            LaunchedEffect(Unit) {
                withFrameNanos { }
                firstFrameReady.set(true)
            }
            VorixSplashScreen(
                onFinished = {
                    startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    finish()
                }
            )
        }
    }
}
