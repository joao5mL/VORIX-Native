package com.vorix.app.ui.animation

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SplashText = Color(0xFFF4F3FF)
private val SplashMuted = Color(0xFF9292AA)

@Composable
fun VorixSplashScreen(progress: Float, logoScale: Float, contentAlpha: Float) {
    val infinite = rememberInfiniteTransition(label = "vorix-splash-glow")
    val glow by infinite.animateFloat(
        initialValue = 0.72f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1150, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )
    val status = when {
        progress < 0.28f -> "Preparando o VORIX..."
        progress < 0.68f -> "Organizando sua experiência..."
        progress < 0.96f -> "Quase pronto..."
        else -> "Tudo pronto!"
    }
    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.radialGradient(
                colors = listOf(Color(0xFF172C45), Color(0xFF111126), Color(0xFF07070D)),
                center = androidx.compose.ui.geometry.Offset(520f, 620f),
                radius = 1180f
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        // Subtle moving ambient light behind the mark.
        Box(
            Modifier.size(220.dp).graphicsLayer { alpha = glow * 0.20f }
                .background(Brush.radialGradient(listOf(Color(0xFF8B5CF6), Color(0xFF06D6B4), Color.Transparent)), CircleShape)
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = com.vorix.app.R.drawable.vorix_splash_logo),
                contentDescription = "Logotipo VORIX",
                modifier = Modifier.size(132.dp)
                    .graphicsLayer {
                        scaleX = logoScale * (0.985f + glow * 0.015f)
                        scaleY = logoScale * (0.985f + glow * 0.015f)
                        alpha = contentAlpha
                    }
                    .shadow(28.dp, RoundedCornerShape(34.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(25.dp))
            Row(
                modifier = Modifier.graphicsLayer { alpha = contentAlpha },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("VOR", color = SplashText, fontSize = 35.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.4.sp)
                Text("IX", color = Color(0xFFB7A5FF), fontSize = 35.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.4.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Vídeos e imagens na máxima qualidade",
                color = SplashMuted.copy(alpha = 0.96f),
                fontSize = 13.sp,
                modifier = Modifier.graphicsLayer { alpha = contentAlpha }
            )
            Spacer(Modifier.height(38.dp))
            // The progress is driven by an Animatable in VorixApp, not a static decoration.
            Box(Modifier.width(190.dp).height(5.dp).clip(CircleShape).background(Color(0xFF29283A))) {
                Box(
                    Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight()
                        .clip(CircleShape).background(
                            Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFF6D7CFF), Color(0xFF21D4C2)))
                        )
                )
            }
            Spacer(Modifier.height(13.dp))
            Text(
                status,
                color = SplashMuted.copy(alpha = 0.88f),
                fontSize = 11.sp,
                modifier = Modifier.graphicsLayer { alpha = contentAlpha }
            )
        }
        Text(
            "VORIX  •  1.5.0",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 34.dp)
                .graphicsLayer { alpha = contentAlpha * 0.78f },
            color = SplashMuted,
            fontSize = 10.sp,
            letterSpacing = 2.sp
        )
    }
}

