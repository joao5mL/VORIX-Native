# VORIX — Android nativo

Projeto Android nativo em Kotlin + Jetpack Compose. Não usa WebView.

## O que já está incluído
- Interface escura inspirada no site original VORIX, com gradiente roxo/azul/ciano.
- Detecção de links TikTok e X/Twitter.
- Extração TikTok via TikWM.
- Extração X via FxTwitter, com fallback VxTwitter.
- Prévia de imagens e miniaturas de vídeo.
- Download nativo para `Downloads/VORIX` via MediaStore.
- Compartilhamento pelo menu nativo do Android.
- Histórico local dos últimos 10 links.
- Painel de detalhes técnicos.
- GitHub Actions para compilar o APK de debug.

## Como compilar pelo GitHub
1. Envie o conteúdo desta pasta para a raiz de um repositório novo.
2. Abra a aba **Actions**.
3. Se necessário, habilite workflows para o repositório.
4. Execute **Build VORIX APK** ou faça um push na branch `main`.
5. Abra a execução concluída e baixe o artefato `VORIX-apk`.

## Privacidade e rede
O app solicita apenas `INTERNET`. Não usa WebView, analytics, publicidade, SDK de rastreamento, acesso a contatos ou localização. O histórico fica em SharedPreferences local. As URLs dos posts são enviadas aos serviços externos de extração necessários para obter a mídia: TikWM, FxTwitter e, como alternativa, VxTwitter. O download de mídia usa a URL retornada pelo serviço e conecta-se diretamente ao host do arquivo. Não são usados proxies CORS públicos.

A disponibilidade, limites e políticas desses serviços externos podem mudar. Use apenas para conteúdo próprio ou que você tenha permissão para baixar.

## Requisitos
- Android Studio / Gradle 8.9
- JDK 17
- Android SDK Platform 35
