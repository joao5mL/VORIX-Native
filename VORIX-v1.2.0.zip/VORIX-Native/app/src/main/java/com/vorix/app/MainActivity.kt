package com.vorix.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.URLUtil
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.FormBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

private val Bg = Color(0xFF07070D)
private val Card = Color(0xFF10101A)
private val Card2 = Color(0xFF151522)
private val Line = Color(0xFF27273A)
private val Txt = Color(0xFFF4F3FF)
private val Muted = Color(0xFF9292AA)
private val Pink = Color(0xFFFF6B9B)
private val Gradient = Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6), Color(0xFF06B6D4)))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 7, 13)
        window.navigationBarColor = android.graphics.Color.rgb(7, 7, 13)
        window.setBackgroundDrawableResource(android.R.color.black)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        setContent { VorixApp() }
    }
}

data class MediaItem(val kind: String, val url: String, val label: String, val name: String, val thumb: String = "", val info: String = "")
data class MediaResult(val platform: String, val title: String, val author: String, val items: List<MediaItem>)
data class HistoryItem(val url: String, val platform: String, val title: String)

private val http = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .followRedirects(true)
    .build()

@Composable
private fun VorixApp() {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<MediaResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Aguardando link") }
    var error by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf("") }
    var logs by remember { mutableStateOf(listOf("VORIX nativo iniciado.")) }
    var history by remember { mutableStateOf(loadHistory(context)) }
    var downloading by remember { mutableStateOf("") }
    var progress by remember { mutableFloatStateOf(0f) }
    var showLogs by remember { mutableStateOf(false) }

    fun log(message: String) { logs = (logs + "[${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}] $message").takeLast(80) }
    fun detect(value: String): String {
        val host = runCatching { Uri.parse(normalizeUrl(value)).host.orEmpty().lowercase() }.getOrDefault("")
        return when {
            host == "tiktok.com" || host.endsWith(".tiktok.com") -> "tiktok"
            host == "x.com" || host.endsWith(".x.com") || host == "twitter.com" || host.endsWith(".twitter.com") || host.contains("fxtwitter.com") || host.contains("vxtwitter.com") || host.contains("fixupx.com") -> "x"
            else -> ""
        }
    }
    fun search(link: String = url) {
        val clean = normalizeUrl(link.trim())
        val platform = detect(clean)
        if (link.isBlank()) { toast = "Cole um link primeiro."; return }
        if (platform.isBlank()) { status = "Link não reconhecido"; error = "Use um link público do TikTok ou do X."; return }
        url = clean; status = if (platform == "x") "X detectado" else "TikTok detectado"
        loading = true; error = ""; result = null; log("Buscando mídia: $clean")
        scope.launch {
            try {
                val data = withContext(Dispatchers.IO) { if (platform == "tiktok") fetchTikTok(clean) else fetchX(clean) }
                if (data.items.isEmpty()) throw Exception("Nenhuma mídia encontrada nesse link.")
                result = data
                val title = (data.title.ifBlank { data.author.ifBlank { clean } }).take(60)
                history = saveHistory(context, HistoryItem(clean, platform, title))
                log("Busca concluída: ${data.items.size} arquivo(s).")
            } catch (e: Exception) {
                error = e.message ?: "Não foi possível buscar essa mídia."
                log("ERRO: $error")
            } finally { loading = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Color(0xFF8B5CF6), onBackground = Txt, onSurface = Txt)) {
        Box(Modifier.fillMaxSize().background(Bg).windowInsetsPadding(WindowInsets.systemBars)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { Header() }
                item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(24.dp)).padding(16.dp)) {
                        OutlinedTextField(
                            value = url,
                            onValueChange = { url = it; status = when (detect(it)) { "tiktok" -> "TikTok detectado"; "x" -> "X detectado"; else -> if (it.isBlank()) "Aguardando link" else "Link não reconhecido" } },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Cole o link aqui...", color = Muted) },
                            leadingIcon = { Icon(Icons.Default.Link, null, tint = Muted) },
                            trailingIcon = { if (url.isNotBlank()) IconButton(onClick = { url = ""; status = "Aguardando link"; result = null; error = "" }) { Icon(Icons.Default.Close, "Limpar", tint = Muted) } },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { search() }),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF8B5CF6), unfocusedBorderColor = Line, focusedTextColor = Txt, unfocusedTextColor = Txt, cursorColor = Color(0xFF8B5CF6))
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            StatusPill(status)
                            OutlinedButton(onClick = {
                                val pasted = clipboard.getText()?.text.orEmpty()
                                if (pasted.isNotBlank()) { url = pasted; search(pasted) } else toast = "A área de transferência está vazia."
                            }, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                                Icon(Icons.Default.ContentPaste, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Colar")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        GradientButton(text = if (loading) "Buscando mídia..." else "Buscar mídia", enabled = !loading) { search() }
                    }
                }
                if (loading) item { LoadingCard() }
                if (error.isNotBlank()) item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(20.dp)).padding(16.dp)) {
                        Text("⚠  $error", color = Pink, fontSize = 14.sp, lineHeight = 20.sp)
                        Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = { search() }) { Text("Tentar novamente") }
                    }
                }
                result?.let { data ->
                    item { ResultHeader(data) }
                    items(data.items, key = { it.name + it.url }) { media ->
                        MediaCard(media = media, downloading = downloading == media.name, progress = if (downloading == media.name) progress else 0f,
                            onDownload = {
                                if (downloading.isNotBlank()) { toast = "Aguarde o download atual terminar." }
                                else {
                                    downloading = media.name; progress = 0f
                                    scope.launch {
                                        try {
                                            val saved = downloadMedia(context, media) { p -> Handler(Looper.getMainLooper()).post { progress = p } }
                                            toast = "Salvo em Downloads/VORIX: ${saved.second}"
                                            log("Download salvo: ${saved.second}")
                                        } catch (e: Exception) { toast = e.message ?: "Falha no download"; log("Download falhou: ${e.message}") }
                                        finally { downloading = ""; progress = 0f }
                                    }
                                }
                            }, onOpen = { openUrl(context, media.url) }, onShare = { shareUrl(context, media.url) })
                    }
                    if (data.items.count { it.kind != "audio" } > 1) item {
                        GradientButton("Baixar tudo", enabled = downloading.isBlank()) {
                            scope.launch {
                                data.items.forEach { media ->
                                    downloading = media.name; progress = 0f
                                    try {
                                        val saved = downloadMedia(context, media) { p -> Handler(Looper.getMainLooper()).post { progress = p } }
                                        log("Download salvo: ${saved.second}")
                                    } catch (e: Exception) { log("Falha em ${media.label}: ${e.message}") }
                                }
                                downloading = ""; toast = "Downloads concluídos. Confira Downloads/VORIX."
                            }
                        }
                    }
                }
                if (history.isNotEmpty()) item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(22.dp)).padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Recentes", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { history = emptyList(); clearHistory(context) }) { Text("Limpar", color = Muted) }
                        }
                        history.forEach { h ->
                            Row(Modifier.fillMaxWidth().clickable { url = h.url; search(h.url) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                StatusPill(if (h.platform == "x") "X detectado" else "TikTok detectado")
                                Spacer(Modifier.width(10.dp)); Text(h.title, color = Txt, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            HorizontalDivider(color = Line.copy(alpha = .65f))
                        }
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(20.dp)).padding(16.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { showLogs = !showLogs }, verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, null, tint = Muted); Spacer(Modifier.width(9.dp)); Text("Detalhes técnicos", fontWeight = FontWeight.SemiBold); Spacer(Modifier.weight(1f)); Icon(if (showLogs) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = Muted)
                        }
                        AnimatedVisibility(showLogs) { Text(logs.joinToString("\n"), color = Muted, fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 12.dp)) }
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("VORIX", fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp, color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(5.dp)); Text("Use apenas para conteúdo seu ou com permissão do autor.", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            if (toast.isNotBlank()) {
                Surface(Modifier.align(Alignment.BottomCenter).padding(18.dp), color = Color(0xFF242438), shape = RoundedCornerShape(14.dp), shadowElevation = 10.dp) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(toast, color = Txt, fontSize = 13.sp, modifier = Modifier.weight(1f)); IconButton(onClick = { toast = "" }, modifier = Modifier.size(26.dp)) { Icon(Icons.Default.Close, null, tint = Muted) }
                    }
                }
            }
        }
    }
}

@Composable private fun Header() {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).shadow(14.dp, RoundedCornerShape(19.dp)).clip(RoundedCornerShape(19.dp)).background(Gradient), contentAlignment = Alignment.Center) {
            Text("V", color = Color.White, fontSize = 37.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("VOR", color = Txt, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            Text("IX", color = Color(0xFF8B7CFF), fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        }
        Text("Vídeos e imagens do TikTok e do X", color = Muted, fontSize = 13.sp)
        Text("na máxima qualidade", color = Muted, fontSize = 13.sp)
    }
}

@Composable private fun StatusPill(text: String) {
    val isTik = text.contains("TikTok")
    Box(Modifier.clip(CircleShape).background(if (isTik) Pink.copy(alpha = .13f) else Color.White.copy(alpha = .09f)).padding(horizontal = 12.dp, vertical = 7.dp)) {
        Text(text, color = if (isTik) Pink else Color(0xFFE6E6F2), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable private fun GradientButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(54.dp).shadow(if (enabled) 9.dp else 0.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Gradient).clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White.copy(alpha = if (enabled) 1f else .65f), fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable private fun LoadingCard() {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(22.dp), color = Color(0xFF8B5CF6), strokeWidth = 2.dp)
        Spacer(Modifier.width(12.dp)); Text("Analisando o link...", color = Muted, fontSize = 13.sp)
    }
}

@Composable private fun ResultHeader(data: MediaResult) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(20.dp)).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { StatusPill(if (data.platform == "x") "X detectado" else "TikTok detectado"); Spacer(Modifier.width(10.dp)); Text(data.author, color = Txt, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        if (data.title.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(data.title.take(240), color = Muted, fontSize = 13.sp, lineHeight = 19.sp) }
    }
}

@Composable
private fun NativeVideoPlayer(url: String, thumbnail: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var playbackError by remember(url) { mutableStateOf("") }
    var firstFrameRendered by remember(url) { mutableStateOf(false) }
    val exoPlayer = remember(url) {
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(
                    DefaultHttpDataSource.Factory()
                        .setUserAgent("Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36")
                        .setAllowCrossProtocolRedirects(true)
                )
            )
            .build().apply {
                repeatMode = Player.REPEAT_MODE_OFF
                playWhenReady = false
                setMediaItem(ExoMediaItem.fromUri(Uri.parse(url)))
                prepare()
            }
    }

    DisposableEffect(exoPlayer, lifecycleOwner) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) firstFrameRendered = true
            }
            override fun onPlayerError(error: PlaybackException) {
                playbackError = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "Falha de conexão ao carregar este vídeo."
                    PlaybackException.ERROR_CODE_DECODING_FAILED,
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "Formato ou codec de vídeo não compatível com este aparelho."
                    else -> "Não foi possível reproduzir este vídeo. Tente abrir ou baixar o arquivo."
                }
            }
        }
        exoPlayer.addListener(listener)
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> exoPlayer.pause()
                Lifecycle.Event.ON_RESUME -> Unit
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    Box(modifier = modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = true
                    controllerAutoShow = true
                    controllerShowTimeoutMs = 3500
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    player = exoPlayer
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    setKeepContentOnPlayerReset(true)
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { view ->
                if (view.player !== exoPlayer) view.player = exoPlayer
            }
        )
        if (!firstFrameRendered) {
            if (thumbnail.isNotBlank()) {
                AsyncImage(
                    model = thumbnail,
                    contentDescription = "Miniatura do vídeo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                )
            } else {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF191827), Color(0xFF080810)))))
            }
            Surface(
                modifier = Modifier.size(58.dp),
                shape = CircleShape,
                color = Color.Black.copy(alpha = .68f),
                onClick = { exoPlayer.play() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Reproduzir vídeo", tint = Color.White, modifier = Modifier.size(39.dp))
                }
            }
        }
        if (playbackError.isNotBlank()) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color.Black.copy(alpha = .82f)).padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(playbackError, color = Color.White, fontSize = 12.sp, lineHeight = 16.sp)
                TextButton(onClick = { playbackError = ""; firstFrameRendered = false; exoPlayer.prepare() }) { Text("Tentar novamente", color = Color(0xFFB69CFF)) }
            }
        }
    }
}

@Composable private fun MediaCard(media: MediaItem, downloading: Boolean, progress: Float, onDownload: () -> Unit, onOpen: () -> Unit, onShare: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(21.dp)).background(Card2).border(1.dp, Line, RoundedCornerShape(21.dp)).padding(12.dp)) {
        if (media.kind == "image") {
            AsyncImage(model = media.url, contentDescription = media.label, modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp, max = 340.dp).clip(RoundedCornerShape(14.dp)))
        } else if (media.kind == "video") {
            NativeVideoPlayer(
                url = media.url,
                thumbnail = media.thumb,
                modifier = Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(14.dp))
            )
        } else {
            Box(Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(14.dp)).background(Bg), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Muted, modifier = Modifier.size(48.dp)) }
        }
        Spacer(Modifier.height(12.dp)); Text(media.label, color = Txt, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        if (media.info.isNotBlank()) { Spacer(Modifier.height(3.dp)); Text(media.info, color = Muted, fontSize = 11.sp) }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = onDownload, enabled = !downloading, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6755D9))) {
                if (downloading) { CircularProgressIndicator(Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp); Spacer(Modifier.width(7.dp)); Text("${(progress * 100).roundToInt()}%") }
                else { Icon(Icons.Default.Download, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Baixar") }
            }
            OutlinedButton(onClick = onOpen, shape = RoundedCornerShape(13.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line), contentPadding = PaddingValues(horizontal = 12.dp)) { Icon(Icons.Default.OpenInNew, null, tint = Muted, modifier = Modifier.size(17.dp)) }
            OutlinedButton(onClick = onShare, shape = RoundedCornerShape(13.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line), contentPadding = PaddingValues(horizontal = 12.dp)) { Icon(Icons.Default.Share, null, tint = Muted, modifier = Modifier.size(17.dp)) }
        }
        if (downloading) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().clip(CircleShape), color = Color(0xFF8B5CF6), trackColor = Line) }
    }
}

private fun normalizeUrl(raw: String): String {
    val trimmed = raw.trim()
    if (trimmed.isBlank()) return trimmed
    val candidate = Regex("(?:https?://)?(?:[\\w-]+\\.)+[a-z]{2,}/[^\\s]*", RegexOption.IGNORE_CASE).find(trimmed)?.value ?: trimmed
    return if (candidate.startsWith("http://", true) || candidate.startsWith("https://", true)) candidate else "https://$candidate"
}

private fun getJson(url: String): JSONObject {
    val request = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36").header("Accept", "application/json").build()
    http.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Servidor respondeu HTTP ${response.code}")
        val body = response.body?.string() ?: throw Exception("Resposta vazia da API")
        return JSONObject(body)
    }
}

private fun fetchTikwmJson(videoUrl: String): JSONObject {
    val form = FormBody.Builder()
        .add("url", videoUrl)
        .add("hd", "1")
        .add("web", "1")
        .add("count", "12")
        .add("cursor", "0")
        .build()
    val postRequest = Request.Builder()
        .url("https://www.tikwm.com/api/")
        .post(form)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36")
        .header("Accept", "application/json, text/plain, */*")
        .header("Origin", "https://www.tikwm.com")
        .header("Referer", "https://www.tikwm.com/")
        .header("X-Requested-With", "XMLHttpRequest")
        .build()
    var postError = ""
    try {
        http.newCall(postRequest).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful) return JSONObject(body)
            postError = "POST HTTP ${response.code}"
        }
    } catch (e: Exception) {
        postError = e.message ?: "falha no POST"
    }

    // Fallback compatível com instalações/rotas do TikWM que ainda aceitam GET.
    val getUrl = "https://www.tikwm.com/api/?hd=1&web=1&url=" + URLEncoder.encode(videoUrl, "UTF-8")
    val getRequest = Request.Builder()
        .url(getUrl)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36")
        .header("Accept", "application/json, text/plain, */*")
        .header("Referer", "https://www.tikwm.com/")
        .build()
    http.newCall(getRequest).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (response.isSuccessful) return JSONObject(body)
        throw Exception("TikWM recusou a consulta (POST $postError; GET HTTP ${response.code}). O serviço pode estar temporariamente bloqueando requisições.")
    }
}

private fun fetchTikTok(url: String): MediaResult {
    val json = fetchTikwmJson(url)
    if (json.optInt("code", -1) != 0 || !json.has("data")) {
        throw Exception("TikTok: ${json.optString("msg", "o TikWM não retornou dados para esse link.")}")
    }
    val d = json.getJSONObject("data")
    val id = d.optString("id", System.currentTimeMillis().toString())
    val items = mutableListOf<MediaItem>()
    val images = d.optJSONArray("images")
    if (images != null && images.length() > 0) {
        for (i in 0 until images.length()) {
            val u = tikFix(images.optString(i))
            if (u.isNotBlank()) items += MediaItem("image", u, "Imagem ${i + 1}", "tiktok_${id}_${i + 1}")
        }
    } else {
        val video = d.optString("hdplay").ifBlank { d.optString("play") }
        if (video.isNotBlank()) items += MediaItem("video", tikFix(video), if (d.optString("hdplay").isNotBlank()) "Vídeo HD (sem marca d'água)" else "Vídeo", "tiktok_$id", tikFix(d.optString("cover")), formatBytes(d.optLong("hd_size", d.optLong("size"))))
    }
    if (d.optString("music").isNotBlank()) items += MediaItem("audio", tikFix(d.optString("music")), "Áudio (MP3)", "tiktok_${id}_audio")
    val author = d.optJSONObject("author")
    val by = author?.optString("nickname").orEmpty().let { n -> if (n.isBlank()) "" else "$n (@${author?.optString("unique_id").orEmpty()})" }
    return MediaResult("tiktok", d.optString("title"), by, items)
}

private fun tikFix(value: String): String = when {
    value.isBlank() -> ""
    value.startsWith("http", true) -> value
    value.startsWith("//") -> "https:$value"
    value.startsWith("/") -> "https://www.tikwm.com$value"
    else -> "https://www.tikwm.com/$value"
}

private fun fetchX(url: String): MediaResult {
    val id = Regex("status(?:es)?/(\\d+)").find(url)?.groupValues?.getOrNull(1) ?: throw Exception("O link do X precisa ser de um post (/status/ID).")
    try {
        val root = getJson("https://api.fxtwitter.com/i/status/$id")
        val tweet = root.optJSONObject("tweet") ?: root.optJSONObject("status") ?: throw Exception(root.optString("message", "Post não encontrado"))
        val media = tweet.optJSONObject("media") ?: JSONObject()
        val items = mutableListOf<MediaItem>()
        val videos = media.optJSONArray("videos") ?: JSONArray()
        for (i in 0 until videos.length()) {
            val v = videos.optJSONObject(i) ?: continue
            val variants = v.optJSONArray("variants") ?: JSONArray()
            val urls = mutableListOf<Pair<String, Int>>()
            for (j in 0 until variants.length()) {
                val variant = variants.optJSONObject(j) ?: continue
                val u = variant.optString("url")
                if (u.contains("mp4", true) || variant.optString("content_type").contains("mp4", true)) urls += u to variant.optInt("bitrate")
            }
            val sorted = urls.sortedByDescending { it.second }.ifEmpty { if (v.optString("url").isNotBlank()) listOf(v.optString("url") to 0) else emptyList() }
            sorted.forEachIndexed { k, pair ->
                val resolution = Regex("/(\\d{3,4})x(\\d{3,4})/").find(pair.first)?.let { " ${it.groupValues[1]}×${it.groupValues[2]}" }.orEmpty()
                items += MediaItem("video", pair.first, (if (v.optString("type") == "gif") "GIF (mp4)" else if (k == 0) "Vídeo (melhor qualidade)" else "Vídeo (qualidade menor)") + resolution, "x_${id}_${i + 1}" + if (k > 0) "_q${k + 1}" else "", v.optString("thumbnail_url"), if (pair.second > 0) "${pair.second / 1000} kbps" else "")
            }
        }
        val photos = media.optJSONArray("photos") ?: JSONArray()
        for (i in 0 until photos.length()) {
            val p = photos.optJSONObject(i) ?: continue
            val photoUrl = originalImage(p.optString("url"))
            items += MediaItem("image", photoUrl, "Imagem original ${i + 1}", "x_${id}_${i + 1}", info = if (p.optInt("width") > 0) "${p.optInt("width")}×${p.optInt("height")}" else "")
        }
        val author = tweet.optJSONObject("author")
        val by = author?.optString("name").orEmpty().let { n -> if (n.isBlank()) "" else "$n (@${author?.optString("screen_name").orEmpty()})" }
        return MediaResult("x", tweet.optString("text"), by, items)
    } catch (first: Exception) {
        val fallback = getJson("https://api.vxtwitter.com/i/status/$id")
        val extended = fallback.optJSONArray("media_extended") ?: JSONArray()
        val items = mutableListOf<MediaItem>()
        for (i in 0 until extended.length()) {
            val m = extended.optJSONObject(i) ?: continue
            val isImage = m.optString("type") == "image"
            val u = if (isImage) originalImage(m.optString("url")) else m.optString("url")
            if (u.isNotBlank()) items += MediaItem(if (isImage) "image" else "video", u, if (isImage) "Imagem original ${i + 1}" else if (m.optString("type") == "gif") "GIF (mp4)" else "Vídeo", "x_${id}_${i + 1}", m.optString("thumbnail_url"))
        }
        if (items.isEmpty()) throw Exception("FxTwitter e VxTwitter não encontraram mídia. ${first.message ?: ""}")
        val by = fallback.optString("user_name").let { n -> if (n.isBlank()) "" else "$n (@${fallback.optString("user_screen_name")})" }
        return MediaResult("x", fallback.optString("text"), by, items)
    }
}

private fun originalImage(raw: String): String = runCatching {
    val uri = Uri.parse(raw)
    if (uri.host == "pbs.twimg.com") uri.buildUpon().appendQueryParameter("name", "orig").build().toString() else raw
}.getOrDefault(raw)

private fun formatBytes(bytes: Long): String = when {
    bytes <= 0 -> ""
    bytes > 1_048_576 -> "%.1f MB".format(bytes / 1_048_576f)
    else -> "${bytes / 1024} KB"
}

private suspend fun downloadMedia(context: Context, media: MediaItem, onProgress: (Float) -> Unit): Pair<Uri, String> = withContext(Dispatchers.IO) {
    val requestBuilder = Request.Builder().url(media.url)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36")
        .header("Accept", "*/*")
    if (media.name.startsWith("tiktok_")) requestBuilder.header("Referer", "https://www.tiktok.com/")
    val request = requestBuilder.build()
    http.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Download recusado: HTTP ${response.code}")
        val body = response.body ?: throw Exception("Arquivo vazio")
        val contentType = body.contentType()?.toString()?.substringBefore(';') ?: "application/octet-stream"
        if (contentType.contains("text/html") || contentType.contains("json")) throw Exception("O servidor não enviou um arquivo de mídia.")
        val ext = extensionFor(contentType, media.kind, media.url)
        val filename = safeName(media.name) + ".$ext"
        val mime = when (ext) { "mp4" -> "video/mp4"; "webm" -> "video/webm"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"; "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; else -> "image/jpeg" }
        val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, filename); put(MediaStore.MediaColumns.MIME_TYPE, mime); put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/VORIX"); put(MediaStore.MediaColumns.IS_PENDING, 1) }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Não foi possível criar o arquivo em Downloads.")
        try {
            context.contentResolver.openOutputStream(uri)?.use { output ->
                body.byteStream().use { input ->
                    val buffer = ByteArray(64 * 1024); var total = 0L; val length = body.contentLength()
                    while (true) {
                        val count = input.read(buffer); if (count < 0) break
                        output.write(buffer, 0, count); total += count
                        if (length > 0) onProgress((total.toFloat() / length).coerceIn(0f, 1f))
                    }
                    output.flush()
                }
            } ?: throw Exception("Falha ao gravar o arquivo.")
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            context.contentResolver.update(uri, done, null, null)
            uri to filename
        } catch (e: Exception) { context.contentResolver.delete(uri, null, null); throw e }
    }
}

private fun extensionFor(mime: String, kind: String, url: String): String {
    val byMime = when (mime.lowercase()) { "video/mp4" -> "mp4"; "video/webm" -> "webm"; "image/jpeg" -> "jpg"; "image/png" -> "png"; "image/webp" -> "webp"; "image/gif" -> "gif"; "audio/mpeg" -> "mp3"; "audio/mp4" -> "m4a"; else -> "" }
    if (byMime.isNotBlank()) return byMime
    val suffix = Regex("\\.(mp4|webm|jpe?g|png|webp|gif|mp3|m4a)(?:$|\\?)", RegexOption.IGNORE_CASE).find(url)?.groupValues?.getOrNull(1)?.lowercase()
    if (!suffix.isNullOrBlank()) return if (suffix == "jpeg") "jpg" else suffix
    return when (kind) { "video" -> "mp4"; "audio" -> "mp3"; else -> "jpg" }
}

private fun safeName(raw: String): String = raw.replace(Regex("[^A-Za-z0-9._-]+"), "_").take(70).ifBlank { "vorix_media" }

private fun shareMedia(context: Context, uri: Uri, name: String, kind: String) {
    val mime = when (kind) { "video" -> "video/*"; "audio" -> "audio/*"; else -> "image/*" }
    val intent = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); putExtra(Intent.EXTRA_SUBJECT, name); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    context.startActivity(Intent.createChooser(intent, "Compartilhar mídia"))
}
private fun shareUrl(context: Context, url: String) {
    val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, url) }
    context.startActivity(Intent.createChooser(intent, "Compartilhar link"))
}
private fun openUrl(context: Context, url: String) { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }

private fun loadHistory(context: Context): List<HistoryItem> = runCatching {
    val arr = JSONArray(context.getSharedPreferences("vorix", Context.MODE_PRIVATE).getString("history", "[]"))
    (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { HistoryItem(it.optString("url"), it.optString("platform"), it.optString("title")) } }
}.getOrDefault(emptyList())

private fun saveHistory(context: Context, item: HistoryItem): List<HistoryItem> {
    val list = (listOf(item) + loadHistory(context).filterNot { it.url == item.url }).take(10)
    val arr = JSONArray(); list.forEach { arr.put(JSONObject().put("url", it.url).put("platform", it.platform).put("title", it.title)) }
    context.getSharedPreferences("vorix", Context.MODE_PRIVATE).edit().putString("history", arr.toString()).apply()
    return list
}
private fun clearHistory(context: Context) { context.getSharedPreferences("vorix", Context.MODE_PRIVATE).edit().remove("history").apply() }
