# VORIX Native — versão 1.1.0

Aplicativo Android nativo em Kotlin + Jetpack Compose. Não utiliza WebView.

## O que há nesta versão

- Interface escura adaptada com insets do sistema para evitar sobreposição com as barras de status e navegação.
- Ícone oficial VORIX em PNG quadrado, com ícones legados e adaptive icons do Android.
- Player de vídeo baseado em AndroidX Media3 / ExoPlayer, com controles, miniatura quando fornecida, carregamento e mensagens de falha.
- Busca de mídia pública do TikTok via TikWM e do X via FxTwitter, com fallback VxTwitter.
- Download para `Downloads/VORIX`, compartilhamento, abertura externa e histórico local de até 10 links.

## Requisitos de build

- JDK 17
- Gradle 8.9
- Android SDK Platform 35 e Build Tools 35.0.0

O workflow `.github/workflows/android.yml` baixa e configura as ferramentas Android no GitHub Actions e gera o APK debug.

## Gerar APK pelo repositório que contém o ZIP

Se o repositório guarda o projeto como `VORIX-Native-Project-v2.zip`, use o arquivo separado `VORIX-build-from-zip.yml` como `.github/workflows/android.yml` na raiz do repositório. O workflow extrai o ZIP, localiza `settings.gradle.kts`, compila e publica o artefato `VORIX-apk-v1.1.0`.

## Privacidade e serviços

O app solicita acesso à internet. Não inclui SDK de anúncios, analytics ou rastreamento. O histórico de links fica no armazenamento privado local do app. Os links enviados para extração são consultados pelos serviços TikWM, FxTwitter e VxTwitter; os arquivos são obtidos dos hosts de mídia retornados por esses serviços. A disponibilidade e as regras desses serviços externos podem mudar.

Use apenas conteúdo seu ou para o qual você tenha autorização.
