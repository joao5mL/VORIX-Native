package com.vorix.app.ui.animation

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vorix.app.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SplashText = Color(0xFFF7F5FF)
private val SplashMuted = Color(0xFFAAA8C0)

@Composable
fun VorixSplashScreen(onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val logoScale = remember { Animatable(0.78f) }
    val logoAlpha = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val infinite = rememberInfiniteTransition(label = "vorix-ambient")
    val glow by infinite.animateFloat(
        initialValue = 0.30f,
        targetValue = 0.82f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "ambient-glow"
    )
    val sheen by infinite.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1900, easing = LinearEasing), RepeatMode.Restart),
        label = "progress-sheen"
    )
    LaunchedEffect(Unit) {
        coroutineScope {
            launch { logoScale.animateTo(1f, tween(850, easing = FastOutSlowInEasing)) }
            launch { logoAlpha.animateTo(1f, tween(620, easing = FastOutSlowInEasing)) }
            launch { delay(280); textAlpha.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
            launch { delay(350); progress.animateTo(1f, tween(2450, easing = LinearEasing)) }
        }
        delay(250)
        onFinished()
    }
    val message = when {
        progress.value < 0.25f -> "Preparando sua experiência"
        progress.value < 0.62f -> "Organizando os recursos"
        progress.value < 0.92f -> "Quase tudo pronto"
        else -> "Tudo pronto"
    }
    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(
                colors = listOf(Color(0xFF102C38), Color(0xFF15132B), Color(0xFF07070D)),
                radius = 1050f
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(260.dp).graphicsLayer { alpha = glow * 0.32f }
                .background(
                    Brush.radialGradient(listOf(Color(0xFF16D6A0), Color(0xFF9B78FF), Color.Transparent)),
                    CircleShape
                )
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.vorix_splash_logo),
                contentDescription = "Logotipo VORIX",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(126.dp)
                    .graphicsLayer {
                        scaleX = logoScale.value
                        scaleY = logoScale.value
                        alpha = logoAlpha.value
                    }
                    .shadow(26.dp, RoundedCornerShape(30.dp))
            )
            Spacer(Modifier.height(25.dp))
            Row(Modifier.graphicsLayer { alpha = textAlpha.value }, verticalAlignment = Alignment.CenterVertically) {
                Text("VOR", color = SplashText, fontSize = 35.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp)
                Text("IX", color = Color(0xFFBDA8FF), fontSize = 35.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp)
            }
            Spacer(Modifier.height(7.dp))
            Text(
                "Vídeos e imagens na máxima qualidade",
                color = SplashMuted,
                fontSize = 13.sp,
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value }
            )
            Spacer(Modifier.height(42.dp))
            Box(Modifier.width(206.dp).height(6.dp).clip(CircleShape).background(Color(0xFF29283A))) {
                Box(
                    Modifier.fillMaxWidth(progress.value.coerceIn(0f, 1f)).fillMaxHeight()
                        .clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(Color(0xFF16D6A0), Color(0xFF8B7CFA), Color(0xFFBBA7FF))))
                )
                Box(
                    Modifier.fillMaxWidth().fillMaxHeight()
                        .graphicsLayer { translationX = sheen * 205.dp.toPx() }
                        .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.24f), Color.Transparent)))
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(message, color = SplashMuted, fontSize = 11.sp, modifier = Modifier.graphicsLayer { alpha = textAlpha.value })
        }
        Text(
            "VORIX  •  1.7.0",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 34.dp)
                .graphicsLayer { alpha = textAlpha.value * 0.78f },
            color = SplashMuted,
            fontSize = 10.sp,
            letterSpacing = 2.sp
        )
    }
}
