# VORIX Native v1.3.0 — versão 1.2.0

Aplicativo Android nativo em Kotlin + Jetpack Compose. Não utiliza WebView.

## O que há nesta versão

- Interface escura adaptada com insets do sistema para evitar sobreposição com as barras de status e navegação.
- Ícone oficial VORIX em PNG quadrado, com ícones legados e adaptive icons do Android.
- Player de vídeo baseado em AndroidX Media3 / ExoPlayer, com controles, miniatura quando fornecida, carregamento e mensagens de falha.
- Busca de mídia pública do TikTok via TikWM e do X via FxTwitter, com fallback VxTwitter.
- Download para `Downloads/VORIX`, compartilhamento, abertura externa e histórico local de até 10 links.

## Requisitos de build

- JDK 17
- Gradle 8.9
- Android SDK Platform 35 e Build Tools 35.0.0

O workflow `.github/workflows/android.yml` baixa e configura as ferramentas Android no GitHub Actions e gera o APK debug.

## Gerar APK pelo repositório que contém o ZIP

Se o repositório guarda o projeto como `VORIX-Native-Project-v2.zip`, use o arquivo separado `VORIX-build-from-zip.yml` como `.github/workflows/android.yml` na raiz do repositório. O workflow extrai o ZIP, localiza `settings.gradle.kts`, compila e publica o artefato `VORIX-apk-v1.2.0`.

## Privacidade e serviços

O app solicita acesso à internet. Não inclui SDK de anúncios, analytics ou rastreamento. O histórico de links fica no armazenamento privado local do app. Os links enviados para extração são consultados pelos serviços TikWM, FxTwitter e VxTwitter; os arquivos são obtidos dos hosts de mídia retornados por esses serviços. A disponibilidade e as regras desses serviços externos podem mudar.

Use apenas conteúdo seu ou para o qual você tenha autorização.


## Correções da versão 1.2.0
- Ícone Android usa a arte quadrada original fornecida, sem ampliar o V em uma camada foreground separada.
- Consulta TikTok ao TikWM tenta primeiro POST form-urlencoded com cabeçalhos de origem/referência e usa GET como fallback.
- Mensagens de falha do TikWM agora distinguem o bloqueio da consulta e a resposta HTTP.


## Versão 1.3.0
- Tela de abertura nativa com identidade visual VORIX, fundo escuro, logotipo centralizado e transição suave para a interface principal.
- Splash compatível com Android 10+ usando AndroidX Core SplashScreen e uma tela de marca em Jetpack Compose.
